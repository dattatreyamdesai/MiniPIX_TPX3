﻿using System;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;

namespace MiniPIXApp
{
    class Program
    {
        [DllImport("pxcore.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern int pxcInitialize(Int32 a, UInt64 b);

        [DllImport("pxcore.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern int pxcExit();

        [DllImport("pxcore.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern int pxcSetTimepix3Mode(int deviceIndex, int operationMode);

        [DllImport("pxcore.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern int pxcGetDeviceDimensions(UInt32 deviceIndex, ref UInt32 width, ref UInt32 height);

        [DllImport("pxcore.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern int pxcMeasureSingleFrameTpx3(
            UInt32 deviceIndex,
            double frameTime,
            [Out] double[] frameToaITot,
            [Out] UInt16[] frameTotEvent,
            ref UInt32 size,
            UInt32 trgStg = 0);

        [DllImport("pxcore.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern int pxcSaveMeasuredFrame(UInt32 deviceIndex, UInt32 frameIndex, string filename);

        static string baseDirectory = @"C:\Users\z004pj2k\Desktop\HiWi\MiniPIXProject_CSharp\MiniPIXSolution\MiniPIXApp\bin\x64\Release\net8.0\Measurements"; // Base directory
        static string iterationFile = Path.Combine(baseDirectory, "iteration_count.txt");

        static void Main(string[] args)
        {
            try
            {
                // Ensure the base directory exists
                if (!Directory.Exists(baseDirectory))
                    Directory.CreateDirectory(baseDirectory);

                // Get today's date and iteration count
                string todayDate = DateTime.Now.ToString("dd-MM-yyyy");
                int iterationCount = GetIterationCount(todayDate);

                // Generate the directory name
                string folderName = $"{todayDate}_{iterationCount:D3}";
                string fullPath = Path.Combine(baseDirectory, folderName);

                // Create the new directory
                Directory.CreateDirectory(fullPath);
                Console.WriteLine($"Created directory: {fullPath}");

                // Increment and save the iteration count
                UpdateIterationCount(todayDate, iterationCount);

                int rc;
                UInt32 deviceIndex = 0;

                Console.WriteLine("Initializing...");
                rc = pxcInitialize(0, 0);
                Console.WriteLine($"pxcInitialize: {rc} (0 is OK)");
                if (rc != 0) return;

                // Get Device Dimensions
                UInt32 width = 0, height = 0;
                rc = pxcGetDeviceDimensions(deviceIndex, ref width, ref height);
                if (rc != 0)
                {
                    Console.WriteLine($"Failed to get dimensions, error code: {rc}");
                    return;
                }

                // Measure Single Frame
                Console.WriteLine("Measuring a single frame...");
                double[] frameToaITot = new double[width * height];
                UInt16[] frameTotEvent = new UInt16[width * height];
                UInt32 frameSize = (UInt32)(width * height);
                rc = pxcMeasureSingleFrameTpx3(deviceIndex, 1.0, frameToaITot, frameTotEvent, ref frameSize);

                if (rc == 0)
                {
                    Console.WriteLine("Frame measurement successful. Saving to file...");

                    // Save the frame as PNG
                    string framePath = Path.Combine(fullPath, "frame.png");
                    rc = pxcSaveMeasuredFrame(deviceIndex, 0, framePath);
                    Console.WriteLine($"Saved frame to {framePath}: {rc} (0 is OK)");

                    // Save the frame data to a text file
                    string dataPath = Path.Combine(fullPath, "MeasuredFrame.txt");
                    using (StreamWriter writer = new StreamWriter(dataPath))
                    {
                        writer.WriteLine("Frame ToA/ITot Data:");
                        for (int i = 0; i < frameToaITot.Length; i++)
                        {
                            writer.WriteLine(frameToaITot[i]);
                        }

                        writer.WriteLine("\nFrame TotEvent Data:");
                        for (int i = 0; i < frameTotEvent.Length; i++)
                        {
                            writer.WriteLine(frameTotEvent[i]);
                        }
                    }

                    Console.WriteLine($"Frame data saved to {dataPath}");
                }
                else
                {
                    Console.WriteLine($"pxcMeasureSingleFrameTpx3 failed with error code: {rc}");
                }

                // Exit
                Console.WriteLine("Exiting...");
                rc = pxcExit();
                Console.WriteLine($"pxcExit: {rc} (0 is OK)");

                Console.ReadKey();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
            }
        }

        static int GetIterationCount(string todayDate)
        {
            // If the iteration file doesn't exist, create it and return 1
            if (!File.Exists(iterationFile))
            {
                File.WriteAllText(iterationFile, $"{todayDate}:1");
                return 1;
            }

            // Read the iteration file and parse the count for today's date
            string[] lines = File.ReadAllLines(iterationFile);
            foreach (string line in lines)
            {
                if (line.StartsWith(todayDate))
                {
                    string[] parts = line.Split(':');
                    return int.Parse(parts[1]) + 1;
                }
            }

            // If today's date is not found, add it with the first iteration
            File.AppendAllText(iterationFile, $"{todayDate}:1{Environment.NewLine}");
            return 1;
        }

        static void UpdateIterationCount(string todayDate, int currentCount)
        {
            // Read the file and update the count for today's date
            string[] lines = File.ReadAllLines(iterationFile);
            bool updated = false;
            for (int i = 0; i < lines.Length; i++)
            {
                if (lines[i].StartsWith(todayDate))
                {
                    lines[i] = $"{todayDate}:{currentCount + 1}";
                    updated = true;
                    break;
                }
            }

            // If not updated, append the new date and count
            if (!updated)
            {
                File.AppendAllText(iterationFile, $"{todayDate}:{currentCount + 1}{Environment.NewLine}");
            }
            else
            {
                // Save the updated lines back to the file
                File.WriteAllLines(iterationFile, lines);
            }
        }
    }
}
