﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Runtime.InteropServices;

namespace MiniPIXProject_With_UI
{
    public partial class Form1 : Form
    {
        [DllImport("pxcore.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern int pxcInitialize(Int32 a, UInt64 b);

        [DllImport("pxcore.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern int pxcExit();

        [DllImport("pxcore.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern int pxcSetTimepix3Mode(int deviceIndex, int operationMode);

        [DllImport("pxcore.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern int pxcMeasureSingleFrameTpx3(
            UInt32 deviceIndex,
            double frameTime,
            [Out] double[] frameToaITot,
            [Out] UInt16[] frameTotEvent,
            ref UInt32 size,
            UInt32 trgStg = 0);

        [DllImport("pxcore.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern int pxcSaveMeasuredFrame(UInt32 deviceIndex, UInt32 frameIndex, string filename);

        private string baseDirectory = @"C:\Measurements";
        private int iterationCount = 0;

        public Form1()
        {
            InitializeComponent();
            Directory.CreateDirectory(baseDirectory); // Ensure base directory exists
        }


        private void btnMeasureFrame_Click(object sender, EventArgs e)
        {
            try
            {
                // Increment the iteration count
                iterationCount++;
                string todayDate = DateTime.Now.ToString("dd-MM-yyyy");
                string folderName = $"{todayDate}_{iterationCount:D3}";
                string fullPath = Path.Combine(baseDirectory, folderName);
                Directory.CreateDirectory(fullPath);

                // Measure and Save Frame
                UInt32 deviceIndex = 0;
                UInt32 width = 256, height = 256; // Example dimensions, update dynamically if required
                double[] frameToaITot = new double[width * height];
                UInt16[] frameTotEvent = new UInt16[width * height];
                UInt32 frameSize = width * height;

                int rc = pxcMeasureSingleFrameTpx3(deviceIndex, 1.0, frameToaITot, frameTotEvent, ref frameSize);
                if (rc == 0)
                {
                    string framePath = Path.Combine(fullPath, "frame.png");
                    pxcSaveMeasuredFrame(deviceIndex, 0, framePath);
                    lblStatus.Text = $"Status: Frame saved to {framePath}";
                }
                else
                {
                    lblStatus.Text = $"Status: Measurement failed (Code: {rc})";
                }
            }
            catch (Exception ex)
            {
                lblStatus.Text = $"Status: Error - {ex.Message}";
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            int rc = pxcExit();
            lblStatus.Text = rc == 0 ? "Status: Exited" : $"Status: Error on Exit (Code: {rc})";
            Application.Exit();
        }

        private void btnInitialize_Click(object sender, EventArgs e)
        {
            int rc = pxcInitialize(0, 0);
            lblStatus.Text = rc == 0 ? "Status: Initialized" : $"Status: Error (Code: {rc})";
        }
    }
}
